exports.handler = async function() { return { statusCode: 200, body: "Dynatrace sync complete" }; };
